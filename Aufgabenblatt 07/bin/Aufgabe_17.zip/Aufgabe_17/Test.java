package Aufgabe_17;

public class Test {

	public static void main(String[] args) {
		
		new GUI();

	}

}
